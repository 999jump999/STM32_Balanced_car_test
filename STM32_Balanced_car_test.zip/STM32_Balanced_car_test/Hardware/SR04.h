#ifndef __SR04_H
#define __SR04_H

void SR04_GPIO_Init(void);
void SR04_TIM2_Init(void);
int Distance_SR04(void);

#endif
