#ifndef __EXTI_H
#define __EXTI_H	

void MPU6050_EXTI_Init(void);

#endif
