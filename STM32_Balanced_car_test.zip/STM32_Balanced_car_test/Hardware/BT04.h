#ifndef __BT04_H
#define __BT04_H

void BT04_Init(void);
void USART2_IRQHandler(void); 
void BT04_Control(void);

#endif
